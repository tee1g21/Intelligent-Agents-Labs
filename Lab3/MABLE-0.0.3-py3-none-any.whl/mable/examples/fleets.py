from typing import Tuple, List

from mable.extensions.fuel_emissions import Fuel, ConsumptionRate, VesselWithEngine, VesselEngine
from mable.transport_operation import CargoCapacity


def get_fuel_mfo():
    """
    Return an 'MFO' fuel instance.

    :return: The fuel instance.
    :rtype Fuel
    """
    fuel_mfo = Fuel(name="MFO", price=430, energy_coefficient=40, co2_coefficient=3.16)
    return fuel_mfo


def default_laden_balast_consumption():
    """
    Returns laden and balast consumption curve specifications.

    :return: Tuple of laden and balast consumption.
    :rtype: Tuple[ConsumptionRate.Data, ConsumptionRate.Data]
    """
    laden_consumption_rate = ConsumptionRate.Data(
        ConsumptionRate,
        base=0.5503,
        speed_power=2.19201,
        factor=1 / 24)
    ballast_consumption_rate = ConsumptionRate.Data(
        ConsumptionRate,
        base=0.1493,
        speed_power=2.3268,
        factor=1 / 24)
    return laden_consumption_rate, ballast_consumption_rate


def example_fleet_1():
    """
    A fleet with one vessel docked in Aberdeen.

    :return: The fleet.
    :rtype: List[VesselWithEngine.Data]
    """
    laden_consumption_rate, ballast_consumption_rate = default_laden_balast_consumption()
    fleet = [VesselWithEngine.Data(
        VesselWithEngine,
        [CargoCapacity.Data(CargoCapacity, cargo_type="Oil", capacity=300000, loading_rate=5000)],
        "Aberdeen-f8ea5ddd09c3",
        speed=14,
        propelling_engine=VesselEngine.Data(
            VesselEngine,
            fuel=f"{get_fuel_mfo().name}",
            idle_consumption=7.13 / 24,
            laden_consumption_rate=laden_consumption_rate,
            ballast_consumption_rate=ballast_consumption_rate,
            loading_consumption=15.53 / 24,
            unloading_consumption=134.37 / 24),
        name="HMS Terror",
        keep_journey_log=False)]
    return fleet


def example_fleet_2():
    """
    A fleet with one vessel docked in Aberdeen.

    :return: The fleet.
    :rtype: List[VesselWithEngine.Data]
    """
    laden_consumption_rate, ballast_consumption_rate = default_laden_balast_consumption()
    fleet = [VesselWithEngine.Data(
        VesselWithEngine,
        [CargoCapacity.Data(CargoCapacity, cargo_type="Oil", capacity=300000, loading_rate=5000)],
        "Aberdeen-f8ea5ddd09c3",
        speed=14,
        propelling_engine=VesselEngine.Data(
            VesselEngine,
            f"{get_fuel_mfo().name}",
            idle_consumption=7.13 / 24,
            laden_consumption_rate=laden_consumption_rate,
            ballast_consumption_rate=ballast_consumption_rate,
            loading_consumption=15.53 / 24,
            unloading_consumption=134.37 / 24),
        name="HMS Erebus",
        keep_journey_log=False)]
    return fleet


def example_fleet_3():
    """
    A fleet with two vessel.

    :return: The fleet.
    :rtype: List[VesselWithEngine.Data]
    """
    fleet = example_fleet_2()
    laden_consumption_rate, ballast_consumption_rate = default_laden_balast_consumption()
    fleet.extend(
        [
            VesselWithEngine.Data(
                VesselWithEngine,
                [CargoCapacity.Data(CargoCapacity, cargo_type="Oil", capacity=300000, loading_rate=5000)],
                "Suez-4ad378ddd198",
                speed=14,
                propelling_engine=VesselEngine.Data(
                    VesselEngine,
                    f"{get_fuel_mfo().name}",
                    idle_consumption=7.13 / 24,
                    laden_consumption_rate=laden_consumption_rate,
                    ballast_consumption_rate=ballast_consumption_rate,
                    loading_consumption=15.53 / 24,
                    unloading_consumption=134.37 / 24),
                name="HMS Resolute",
                keep_journey_log=False)])
    return fleet
