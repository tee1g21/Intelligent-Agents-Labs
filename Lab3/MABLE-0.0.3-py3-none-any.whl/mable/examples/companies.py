from mable.cargo_bidding import TradingCompany
from mable.transport_operation import ScheduleProposal


class PondPlayer(TradingCompany):

    def receive(self, contracts, auction_ledger=None, *args, **kwargs):
        if self.headquarters.current_time == 30:
            self.fleet[0].location = self.headquarters.get_network_port_or_default(
                "Helgoland-c47a1ee22838", None)
            self.fleet[1].location = self.headquarters.get_network_port_or_default(
                "Colombo-04104bbca75f", None)


class MyArchEnemy(TradingCompany):

    def propose_schedules(self, trades):
        schedules = {}
        costs = {}
        scheduled_trades = []
        i = 0
        while i < len(trades):
            current_trade = trades[i]
            is_assigned = False
            j = 0
            while j < len(self._fleet) and not is_assigned:
                current_vessel = self.fleet[j]
                current_vessel_schedule = schedules.get(current_vessel, current_vessel.schedule)
                new_schedule = current_vessel_schedule.copy()
                new_schedule.add_transportation(current_trade)
                if new_schedule.verify_schedule():
                    loading_time = current_vessel.get_loading_time(current_trade.cargo_type, current_trade.amount)
                    loading_costs = current_vessel.get_loading_consumption(loading_time)
                    unloading_costs = current_vessel.get_unloading_consumption(loading_time)
                    travel_distance = self.headquarters.get_network_distance(
                        current_trade.origin_port, current_trade.destination_port)
                    travel_time = current_vessel.get_travel_time(travel_distance)
                    travel_cost = current_vessel.get_laden_consumption(travel_time, current_vessel.speed)
                    total_costs = loading_costs + unloading_costs + travel_cost
                    costs[current_trade] = total_costs * 1.65
                    schedules[current_vessel] = new_schedule
                    scheduled_trades.append(current_trade)
                    is_assigned = True
                j += 1
            i += 1
        return ScheduleProposal(schedules, scheduled_trades, costs)
