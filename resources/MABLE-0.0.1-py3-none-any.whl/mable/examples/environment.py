import os.path
import json
from zipfile import ZipFile

from loguru import logger

import mable.extensions.world_ports as world_ports
from mable.competition.generation import CompetitionBuilder, AuctionClassFactory
from mable.engine import SimulationEngine
from mable.examples import fleets
from mable.extensions.fuel_emissions import FuelSpecsBuilder
from mable.observers import LogRunner, AuctionMetricsObserver, EventFuelPrintObserver, MetricsObserver
from mable.util import JsonAbleEncoder


def get_specification_builder(environment_files_path="."):
    specifications_builder = _get_specification_builder()
    _generate_environment(specifications_builder, environment_files_path=environment_files_path)
    return specifications_builder


def _get_specification_builder():
    specifications_builder = FuelSpecsBuilder()
    specifications_builder.add_fuel(fleets.get_fuel_mfo())
    return specifications_builder


def _generate_environment(specifications_builder, environment_files_path="."):
    try:
        resource_files = {
            "precomputed_routes": "precomputed_routes.pickle",
            "routing_graph_world_mask": "routing_graph_world_mask.pkl",
            "time_transition_distribution": "time_transition_distribution.csv",
            "port_cargo_weight_distribution": "port_cargo_weight_distribution.csv",
            "port_trade_frequency_distribution": "port_trade_frequency_distribution.csv",
            "ports": "ports.csv"
        }
        resources_archive_path = os.path.join(environment_files_path, "mable_resources.zip")
        resources_archive = ZipFile(resources_archive_path)
        for one_resource_file_key in resource_files:
            if not os.path.isfile(resource_files[one_resource_file_key]):
                resources_archive.extract(resource_files[one_resource_file_key])
        real_ports = world_ports.get_ports(resource_files["ports"])
        specifications_builder.add_shipping_network(
            ports=real_ports,
            precomputed_routes_file=resource_files["precomputed_routes"],
            graph_file=resource_files["routing_graph_world_mask"])
        transition_duration_path = resource_files["time_transition_distribution"]
        cargo_weight_path = resource_files["port_cargo_weight_distribution"]
        trade_frequency_path = resource_files["port_trade_frequency_distribution"]
        specifications_builder.add_cargo_generation(
            port_transition_duration_distributions_path=transition_duration_path,
            port_cargo_weight_distribution_path=cargo_weight_path,
            port_trade_frequency_distribution_path=trade_frequency_path)
    except FileNotFoundError as e:
        logger.exception({f"Environment file(s) not found: {e}"})
        raise e


def generate_simulation(specifications_builder):
    specifications = specifications_builder.build()
    sim_factory = CompetitionBuilder(AuctionClassFactory(), specifications)
    pre_run = ([LogRunner(logger, "---Pre Run Start---")]
               + SimulationEngine.PRE_RUN_CMDS
               + [LogRunner(logger, "--Run Start (Pre Run Finished)---")])
    post_run = [LogRunner(logger, "--Run Finished---"), export_stats]
    sim = sim_factory.generate_engine(pre_run_cmds=pre_run, post_run_cmds=post_run)
    activate_stats_collection(sim)
    return sim


def activate_stats_collection(simulation):
    metric_observer = AuctionMetricsObserver()
    metric_observer.metrics.set_engine(simulation)
    simulation.register_event_observer(EventFuelPrintObserver(logger))
    simulation.register_event_observer(metric_observer)


def export_stats(simulation):
    for one_event_observer in simulation.get_event_observers():
        if isinstance(one_event_observer, MetricsObserver):
            metrics = one_event_observer.metrics.to_json()
            metrics["global_metrics"]["penalty"] = calculate_penalty(simulation)
            with open(f"metrics_competition_{id(one_event_observer)}.json", "w") as metrics_file:
                json.dump(metrics, metrics_file, indent=4, cls=JsonAbleEncoder)


def calculate_penalty(simulation):
    return {0: 0, 1: 0}  # TODO calculate penalty
