"""
Classes and functions around companies bidding for cargoes.
"""

import math
from typing import TYPE_CHECKING

from mable.transport_operation import SimpleCompany, Bid


if TYPE_CHECKING:
    pass


class TradingCompany(SimpleCompany):

    def inform(self, trades, *args, **kwargs):
        """
        The shipping company that bids in cargo auctions.
        :param trades: The list of trades.
        :type trades: list[Trade]
        :param args: Not used.
        :param kwargs: Not used.
        :return: The bids of the company
        :rtype: list[Bid]
        """
        proposed_scheduling = self.propose_schedules(trades)
        scheduled_trades = proposed_scheduling.scheduled_trades
        self._current_scheduling_proposal = proposed_scheduling
        bids = [Bid(amount=math.inf, trade=one_trade) for one_trade in scheduled_trades]
        return bids

    def receive(self, contracts, auction_ledger=None, *args, **kwargs):
        """
        Allocate a list of trades to the company.
        :param contracts: The list of trades.
        :type contracts: List[Contract]
        :param auction_ledger: Outcomes of all cargo auctions in the round.
        :type auction_ledger: AuctionLedger | None
        :param args: Not used.
        :param kwargs: Not used.
        """
        trades = [one_contract.trade for one_contract in contracts]
        scheduling_proposal = self.propose_schedules(trades)
        self.apply_schedules(scheduling_proposal.schedules)


class MeansCompany(TradingCompany):

    def inform(self, trades, auction_ledger=None, *args, **kwargs):
        """
        The shipping company ...
        :param trades: The list of trades.
        :type trades: list[Trade]
        :param auction_ledger: Outcomes of all cargo auctions in the round.
        :type auction_ledger: AuctionLedger | None
        :param args: Not used.
        :param kwargs: Not used.
        :return: The bids of the company
        :rtype: list[Bid]
        """
        proposed_scheduling = self.propose_schedules(trades)
        scheduled_trades = proposed_scheduling.scheduled_trades
        self._current_scheduling_proposal = proposed_scheduling
        bids = [Bid(amount=math.inf, trade=one_trade) for one_trade in scheduled_trades]
        return bids


class MCSTCompany(TradingCompany):

    def inform(self, trades, auction_ledger=None, *args, **kwargs):
        """
        The shipping company ...
        :param trades: The list of trades.
        :type trades: list[Trade]
        :param auction_ledger: Outcomes of all cargo auctions in the round.
        :type auction_ledger: AuctionLedger | None
        :param args: Not used.
        :param kwargs: Not used.
        :return: The bids of the company
        """
        proposed_scheduling = self.propose_schedules(trades)
        scheduled_trades = proposed_scheduling.scheduled_trades
        self._current_scheduling_proposal = proposed_scheduling
        bids = [Bid(amount=math.inf, trade=one_trade) for one_trade in scheduled_trades]
        return bids
