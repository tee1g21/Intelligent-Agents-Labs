"""
All cargo generation and distribution related classes.
"""
import copy
from abc import abstractmethod
from enum import Enum
from typing import Union, Hashable, TYPE_CHECKING
import logging
import math

import attrs

from mable.util import JsonAble
from mable.simulation_space import Port
from mable.simulation_environment import SimulationEngineAware


if TYPE_CHECKING:
    pass


logger = logging.getLogger(__name__)


class Shipping(SimulationEngineAware):
    """
    A unit to generate and/or manage the occurrence of cargo events.
    """

    def __init__(self, *args, **kwargs):
        """
        Constructor. Calls :py:func:`initialise_trades` with all args and kwargs.
        :param args:
            Positional args.
        :param kwargs:
            Keyword args.
        """
        super().__init__()
        self._all_trades = {}
        self.initialise_trades(*args, **kwargs)

    @abstractmethod
    def initialise_trades(self, *args, **kwargs):
        """
        Generate all trades.
        """
        pass

    def add_to_all_trades(self, trades):
        """
        Add all trades from a list of trades to the list of known shippable trades.
        :param trades:
        :return:
        """
        for one_trade in trades:
            if one_trade.time not in self._all_trades:
                self._all_trades[one_trade.time] = []
            self._all_trades[one_trade.time].append(one_trade)

    def get_trading_times(self):
        """
        All times at which new cargoes will become available.
        :return: list
            The list of times.
        """
        times = list(self._all_trades.keys())
        return times

    def get_trades(self, time):
        """
        Get trades for a specific time.
        :param time: float
            The time.
        :return: list[Trades]
            The list of trades.
        """
        trades = []
        if time in self._all_trades:
            trades = self._all_trades[time]
        all_occurring_trades = [
            t for t in trades
            if self._engine.world.random.choice([0, 1], p=[1 - t.probability, t.probability])]
        logger.info(f"{len(all_occurring_trades)} trades of a total of {len(trades)} trades realised.")
        for one_trade in [t for t in trades if t not in all_occurring_trades]:
            one_trade.status = TradeStatus.NOT_REALISED
        return all_occurring_trades


class TradeStatus(Enum):
    UNKNOWN = 1
    NOT_REALISED = 2
    ACCEPTED = 3
    REJECTED = 4


@attrs.define(kw_only=True)
class Trade(JsonAble):
    """
    A trade opportunity specifying a cargo that shall be transported.
    :param origin_port: Union[Port, str]
        The origin of the trade where the cargo has to be picked up.
    :param destination_port: Union[Port, str]
        The destination of the trade where the cargo has to be dropped off.
    :param amount: float
        The amount of cargo to be transported.
    :param cargo_type:
        The type of cargo.
    :param time:
        The time that trade becomes available for allocation or a market etc..
    """
    origin_port: Union[Port, str]
    destination_port: Union[Port, str]
    amount: float
    cargo_type: Hashable = None
    time: int = 0
    probability: float = 1
    status: TradeStatus = TradeStatus.UNKNOWN

    def to_json(self):
        # noinspection PyTypeChecker
        # Trade is an attrs instance.
        return attrs.asdict(self)


@attrs.define(kw_only=True)
class TimeWindowTrade(Trade):
    """
    A trade with a time window.

    See :py:class:`maritime_simulator:shipping_market.Trade`
    """
    time_window: list = [None, None, None, None]

    @property
    def earliest_pickup(self):
        return self.time_window[0]

    @property
    def earliest_pickup_clean(self):
        time = self.earliest_pickup
        if time is None:
            time = 0
        return time

    @property
    def latest_pickup(self):
        return self.time_window[1]

    @property
    def latest_pickup_clean(self):
        time = self.latest_pickup
        if time is None:
            time = math.inf
        return time

    @property
    def earliest_drop_off(self):
        return self.time_window[2]

    @property
    def earliest_drop_off_clean(self):
        time = self.earliest_drop_off
        if time is None:
            time = 0
        return time

    @property
    def latest_drop_off(self):
        return self.time_window[3]

    @property
    def latest_drop_off_clean(self):
        time = self.latest_drop_off
        if time is None:
            time = math.inf
        return time

    def clean_window(self):
        return [self.earliest_pickup_clean, self.latest_pickup_clean,
                self.earliest_drop_off_clean, self.latest_drop_off_clean]


class StaticShipping(Shipping):
    """
    A shipping unit that simply takes a list of trades.
    """

    def initialise_trades(self, *args, **kwargs):
        """
        Initialises the shipping with a list of trades.
        :param args:
            args[0] should be a list of specifications for trades.
        :param kwargs:
            kwargs["class_factory"] should be a :py:class`ClassFactory` or any object with a function
            'generate_trade' to generate a trades from specifications.
        """
        for one_trade in args[0]:
            one_trade = kwargs["class_factory"].generate_trade(**one_trade)
            if one_trade.time not in self._all_trades:
                self._all_trades[one_trade.time] = []
            self._all_trades[one_trade.time].append(one_trade)


class Market:
    """
    A market to distribute the trades.
    """

    @abstractmethod
    def __init__(self, *args, **kwargs):
        super().__init__()

    @staticmethod
    @abstractmethod
    def distribute_trades(time, trades, shipping_companies):
        """
        Conducts the distribution of trades at specified time to the shipping companies.
        :param time: float
            The time of occurrence.
        :param trades: [Trade]
            The list of trades.
        :param shipping_companies: [ShippingCompany]
            The list of shipping companies.
        """
        pass


class SimpleMarket(Market, SimulationEngineAware):
    """
    A simple market which gives the first shipping company all requested trades.
    """

    def __init__(self, *args, **kwargs):
        super().__init__()

    @staticmethod
    def distribute_trades(time, trades, shipping_companies):
        """
        Distribute trades to the first shipping company. The company is first informed about all trades and is expected
        to return a list of requested trades which are then directly allocated to the company.
        The shipping
        :param time: float
            The time of occurrence.
        :param trades: [Trade]
            The list of trades.
        :param shipping_companies: [ShippingCompany]
            The list of shipping companies.
        """
        first_company = shipping_companies[0]
        request = first_company.inform(trades)
        first_company.receive(request)


@attrs.define(kw_only=True)
class Contract(JsonAble):
    """
    A cargo transportation contract.
    :param payment:
        The amount which is paid for the transportation.
    :type payment: float
    :param trade:
        The trade the company has to transport.
    :type trade: Trade
    """
    payment: float
    trade: Trade

    def copy(self):
        return copy.deepcopy(self)

    def to_json(self):
        # noinspection PyTypeChecker
        # Contract is an attrs instance.
        return attrs.asdict(self)


class AuctionLedger:

    def __init__(self, shipping_companies):
        self._ledger = {one_company: [] for one_company in shipping_companies}

    @property
    def sanitised_ledger(self):
        sanitised_ledger = {k.name: [c.copy() for c in self._ledger[k]] for k in self._ledger}
        return sanitised_ledger

    def get_trades_for_company_copy(self, shipping_company):
        trades = [copy.deepcopy(t) for t in self[shipping_company]]
        return trades

    def __getitem__(self, shipping_company):
        return self._ledger[shipping_company]

    def __setitem__(self, shipping_company, value):
        self._ledger[shipping_company] = value

    @property
    def keys(self):
        return self._ledger.keys


class AuctionMarket(Market, SimulationEngineAware):
    """
    A market which auctions of trades.
    """

    def __init__(self, *args, **kwargs):
        super().__init__()

    @staticmethod
    def _get_trade_index(trade, all_trades):
        return all_trades.index(trade)

    @staticmethod
    def inform_future_trades(trades, shipping_companies):
        """
        Informs the shipping companies of upcoming trades.
        :param trades:
            The list of trades.
        :type trades: list[Trade]
        :param shipping_companies:
            The list of shipping companies.
        :type shipping_companies: list[ShippingCompany]
        """
        for current_company in shipping_companies:
            # TODO timeout
            current_company.inform(trades, announcement=True)

    @staticmethod
    def inform_auction_outcome(ledger, time, shipping_companies):
        """
        Inform shipping companies of all allocated trades.
        :param ledger:
        :type ledger: AuctionLedger
        :param time: The time of the auction
        :type time: int
        :param shipping_companies:
        :type shipping_companies: list[ShippingCompany]
        :return:
        """
        for current_company in shipping_companies:
            # TODO timeout for this
            current_company.pre_inform(ledger, time)

    @staticmethod
    def distribute_trades(time, trades, shipping_companies):
        """
        Distribute trades on a second price auction basis. The shipping companies are
        informed (ShippingCompany.receive) of the trades they get allocated via Contracts. All allocations
        are also returned.
        :param time:
            The time of occurrence.
        :type time: float
        :param trades:
            The list of trades.
        :type trades: list[Trade]
        :param shipping_companies:
            The list of shipping companies.
        :type shipping_companies: list[ShippingCompany]
        :return: All allocated traded per company.
        :rtype: AuctionLedger
        """
        all_bids_per_trade = {i: [] for i in range(len(trades))}
        ledger = AuctionLedger(shipping_companies)
        for current_company in shipping_companies:
            # TODO timeout for this
            company_bids = current_company.inform(trades)
            for one_bid in company_bids:
                one_bid.company = current_company
                all_bids_per_trade[AuctionMarket._get_trade_index(one_bid.trade, trades)].append(one_bid)
        for one_trade in trades:
            all_bids_for_current_trade = all_bids_per_trade[AuctionMarket._get_trade_index(one_trade, trades)]
            if len(all_bids_for_current_trade) > 0:
                all_bids_for_trade = sorted(all_bids_for_current_trade, key=lambda b: b.amount, reverse=True)
                smallest_bid_company = all_bids_for_trade[0].company
                if len(all_bids_for_current_trade) > 1:
                    payment = all_bids_for_current_trade[1].amount
                else:
                    payment = all_bids_for_current_trade[0].amount
                trade_contract = Contract(payment=payment, trade=one_trade)
                ledger[smallest_bid_company].append(trade_contract)
        return ledger
